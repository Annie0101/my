<?php	if(!defined('IN_PHPMYWIND')) exit('Request Error!');

/*
**************************
(C)2010-2015 phpMyWind.com
**************************
*/

//数据库服务器
$db_host = 'localhost';

//数据库用户名
$db_user = 'root';

//数据库密码
$db_pwd = 'root';

//数据库名
$db_name = 'phpmywind_db';

//数据表前缀
$db_tablepre = 'pmw_';

//数据表编码
$db_charset = 'utf8';

?>
