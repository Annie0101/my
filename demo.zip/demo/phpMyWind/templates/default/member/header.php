<?php if(!defined('IN_MEMBER')) exit('Request Error!'); ?>
<div class="area">
	<div class="logo"><a href="<?php echo $cfg_webpath; ?>/"></a></div>
	<div class="retxt"><a href="<?php echo $cfg_webpath; ?>/">网站首页</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="?a=logout">退出</a></div>
</div>