<?php exit(); ?> Time: 2017-06-30 09:43:20. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-06-30 09:43:24. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-06-30 09:43:28. || Page: /phpMyWind/admin/login.php || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-06-30 09:43:34. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-06-30 02:02:56. || Page: /phpMyWind/admin/infoimg_do.php || IP: 0.0.0.0 || Error: 连接数据库失败，可能数据库密码不对或数据库服务器出错！
<?php exit(); ?> Time: 2017-07-03 14:11:20. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-07-03 14:12:09. || Page: /phpMyWind/admin/login.php || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-07-03 15:57:34. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ESC LIMIT 0,3' at line 1 Error sql: SELECT * FROM `pmw_infolist` WHERE classid=14 AND delstate='' AND checkinfo=true ORDER BY orderid ESC LIMIT 0,3
<?php exit(); ?> Time: 2017-07-03 19:11:25. || Page: /phpMyWind/ || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-07-03 19:11:32. || Page: /phpMyWind/admin/login.php || IP: 0.0.0.0 || Error: 无法使用数据库！
<?php exit(); ?> Time: 2017-07-04 01:20:51. || Page: /phpMyWind/news.php || IP: 0.0.0.0 || Error: 连接数据库失败，可能数据库密码不对或数据库服务器出错！
<?php exit(); ?> Time: 2017-07-04 02:38:41. || Page: /phpMyWind/about.php || IP: 0.0.0.0 || Error: 连接数据库失败，可能数据库密码不对或数据库服务器出错！
<?php exit(); ?> Time: 2017-07-04 03:59:15. || Page: /phpMyWind/product.php || IP: 0.0.0.0 || Error: 连接数据库失败，可能数据库密码不对或数据库服务器出错！
