<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>introduction</title>
	<link rel="stylesheet" type="text/css" href="./common/introduction.css">
</head>
<body>
	<div class="myDiv">
		<nav class="navDiv">
			<div class="myImg">
				<img src="./images/detailsNav.jpg" alt="" style="width: 1900px; height: 230px";>
				<p>解决方案</p>
				<span>您当前所在位置:首页>解决方案</span>
			</div>
			<div class="myLine"></div>
		</nav>
	</div>
</body>
</html>