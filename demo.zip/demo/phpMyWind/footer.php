		<footer class="myfooter">
			<div class="container">
				<div class="row">
					<div class="col-lg-7 col-md-7">
						<div class="myimg4">
							<img src="./images/header-logo.png" alt="">
							<p>合作热线:4008745099 18307459777 公司地址:湖南省长沙市鹤城区河西市政府大楼<br/>
							Copyright &copy; 2014 - 2017 aorise All Rights Reserved<br />
							本栏目文字内容归aorise.cn所有,任何单位及个人未经许可，不得擅自转摘使用</p>
						</div>
					</div>
						<div class="col-md-4 col-md-7">
							<div class="code">
								<img src="./images/scanCode.png" alt="">
								<p>奥昇教育公众号</p>
							</div>
						</div>
				</div>
			</div>
		</footer>